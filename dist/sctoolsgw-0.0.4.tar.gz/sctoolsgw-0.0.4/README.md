# sctoolsgw

Convenience wrappers around common functions and workflows from the [scanpy](https://github.com/scverse/scanpy) package.
